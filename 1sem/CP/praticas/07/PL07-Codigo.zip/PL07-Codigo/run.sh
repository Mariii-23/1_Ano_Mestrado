#!/bin/bash


SORT_SIZE=100000

module load papi/5.4.1
./sort  $SORT_SIZE
