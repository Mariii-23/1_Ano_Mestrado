#ifndef __QUICKSORT__
#define __QUICKSORT__

void quickSort(float* arr, int size); 

#endif

