#!/bin/bash


time  ./a.out
